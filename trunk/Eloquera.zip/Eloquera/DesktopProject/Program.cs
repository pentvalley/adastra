﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Linq;
using Eloquera.Client;

using Accord.Statistics.Analysis;
//using AForge.Neuro;
//using AForge.Neuro.Learning;

namespace DesktopProject
{
    public class SampleClass
    {
        public int Value { get; set; }
        public string Tag { get; set; }
    }

    class Program
    {
        public static void Main(string[] args)
        {
            const string dbName = "SampleDb";
            string fullpath = "d:\\" + dbName;

            var db = new DB("server=(local);options=none;");

            //db.DeleteDatabase(dbName, true);
            if (!File.Exists(fullpath+".eq"))
                db.CreateDatabase(fullpath);

            db.OpenDatabase(fullpath);

            if (!db.IsTypeRegistered(typeof(LinearDiscriminantAnalysis)))
            db.RegisterType(typeof(LinearDiscriminantAnalysis));
            // Insert your code here

            // Sample LINQ query
            double[,] inputs=new double [,] {{3,4}};
            int[] output=new int[] {1};
            LinearDiscriminantAnalysis lda = new LinearDiscriminantAnalysis(inputs,output);
            //db.Store(new SampleClass() { Value = 123, Tag="Hello " });
            //db.Store(new SampleClass() { Value = 124, Tag="Goodbye " });
            //db.Store(new SampleClass() { Value = 123, Tag = "World!" });

            db.Store(lda);

            db.Close();

            db.OpenDatabase(fullpath);

            var result = from LinearDiscriminantAnalysis sample in db select sample;

            foreach(var item in result)
            {
                Console.WriteLine(item.ToString());
            }

            Console.WriteLine();

            // End of sample LINQ query

            db.Close();
        }
    }
}
